// Initialize the board data
let boardData = [
   -1, 1, -1, -1, -1, -1, -1, 9, -1,
   -1, -1, 4, -1, -1, -1, 2, -1, -1,
   -1, -1, 8, -1, -1, 5, -1, -1, -1,
   -1, -1, -1, -1, -1, -1, -1, 3, -1,
   2, -1, -1, -1, 4, -1, 1, -1, -1,
   -1, -1, -1, -1, -1, -1, -1, -1, -1,
   -1, -1, 1, 8, -1, -1, 6, -1, -1,
   -1, 3, -1, -1, -1, -1, -1, 8, -1,
   -1, -1, 6, -1, -1, -1, -1, -1, -1
];

let board, cols, valid = true, boards = [], palette, selected, rows = [];

function sameBlock(x1, y1, x2, y2) {
   let firstRow = Math.floor(y1 / 3) * 3;
   let firstCol = Math.floor(x1 / 3) * 3;
   return (y2 >= firstRow && y2 <= (firstRow + 2) && x2 >= firstCol && x2 <= (firstCol + 2));
}

function sameRow(x1, y1, x2, y2) {
   return y1 == y2;
}

function sameColumn(x1, y1, x2, y2) {
   return x1 == x2;
}

function checkConflicts(x, y, value) {
   for (let i = 0; i < 9; i++) {
       let xi = i % 9;
       let yi = Math.floor(i / 9);
       let cellValue = boardData[boardPosition(xi, yi)];
       if (cellValue == value && (sameRow(xi, yi, x, y) || sameColumn(xi, yi, x, y) || sameBlock(xi, yi, x, y))) {
           return true;
       }
   }
   return false;
}

function addToBoard() {
   boards.push($('#board').html()); // Save the current state of the board
   
   let td = $(this);
   let id = td.attr('id'); // get the id from the cell

   let x = parseInt(id.split('_')[1]); // Get the column number from the cell ID
   let y = parseInt(id.split('_')[0]); // Get the row number from the cell ID

   if (selected != null && td.find('span').text() === '') {
       let conflict = checkConflicts(x, y, selected);
       let span = document.createElement('span');
       span.textContent = selected;
       if (!conflict) {
           td.append(span);
           boardData[boardPosition(x, y)] = selected;
       } else {
           td.addClass('error');
       }
   } else {
       $('#noSelectionError').show(); // Show error if no number is selected
   }
}

function boardPosition(x, y) {
   return y * 9 + x;
}

function undo() {
   if (boards.length > 0) {
       $('#board').html(boards.pop());
   } // Revert the board to the last saved state
}

$(document).ready(function() {
   board = $('#board'); // get the game board
   cols = $('#board tr td');  // get all game board columns
   palette = $('#palette');   // get the number selection palette
   rows = $('#board tr');  // get all game board rows

   // Generate game board
   for(let colNum = 0; colNum < 9; colNum++){
       let tr = document.createElement('tr');
       for (let rowNum = 0; rowNum < 9; rowNum++) {
           let val = boardData[boardPosition(rowNum, colNum)];
           let td = document.createElement('td');
           td.id = rowNum + '_' + colNum;
           let span = document.createElement('span');
           if (val > 0) {
               span.textContent = val;
               td.className = 'disabled';
           }
           td.append(span);
           tr.append(td);
       }
       board.append(tr);
       palette.append('<li>' + (colNum + 1) + '</li>');
   }

   $( "<div id=\"noSelectionError\" class=\"error-text\" style=\"display: none\">\n" +
       "       Please select a number below to add to the board\n" +
       "   </div>" ).insertBefore( "#palette" );
   palette.append('<li id="undo" onclick="undo()"><img src="./images/undo.png" /></li>');

   $('#board tr td').click(addToBoard); // Initialize click event for board cells
   $('#palette li').click(function() {
       $('.selected').removeClass('selected'); // Remove 'selected' class from previous selection
       $(this).addClass('selected'); // Add 'selected' class to current selection
       selected = $(this).text(); // Store selected number
   }); // Initialize click event for number selection
});
